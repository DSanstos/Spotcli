<?php
// HEADER INDEX PARA SGDM
    session_start();
     
    error_reporting(E_ALL);
    ini_set("display_errors", 1);
    
    //Verifico se o usuário está logado no sistema
    if (!isset($_COOKIE['s3I'])) {
        die();
    }

    require_once "../../../api/config/conectadb.php";

    $arrDir = explode("\\", __FILE__);
    $nomeModulo = $arrDir[7].'/'.$arrDir[8];;
    $full_url = URL_COMPLETA;
    $full_url_module = $full_url.'/'.PASTA_PRINCIPAL.'//modules/'.$nomeModulo;

    if( !parametro::getAcesso($nomeModulo, $_COOKIE['s3P'])){
        echo 'Acesso Bloqueado!';
        die();
    }

    $nomeMenu = parametro::getNomeMenu($nomeModulo);
    $nomeIcone = parametro::getIconMenu($nomeModulo);

    $pdo = $conn;

?> 

<!-- DATA TABES styles -->
<link rel="stylesheet" media="screen, print" href="<?=$full_url?>/<?=PASTA_PRINCIPAL?>/css/datagrid/datatables/datatables.bundle.css">
<link rel="stylesheet" type="text/css" href="<?=$full_url?>/<?=PASTA_PRINCIPAL?>/assets/datatables1_9_6/Editor-1.9.6/css/editor.dataTables.css">
<link rel="stylesheet" type="text/css" href="<?=$full_url?>/<?=PASTA_PRINCIPAL?>/assets/datatables1_9_6/Select-1.3.1/css/select.dataTables.css">
<link rel="stylesheet" type="text/css" href="<?=$full_url?>/<?=PASTA_PRINCIPAL?>/assets/datatables1_9_6/Buttons-1.6.5/css/buttons.dataTables.css">
<link rel="stylesheet" type="text/css" href="<?=$full_url?>/<?=PASTA_PRINCIPAL?>/assets/datatables1_9_6/select2-4.0.2/select2.min.css">

<style>

    div.DTED_Lightbox_Wrapper div.DTED_Lightbox_Container div.DTED_Lightbox_Content_Wrapper {
        display: table-cell;
        vertical-align: inherit;
        width: 100%;
        padding-top: 60px;
    }

    .dt-buttons {
        text-align: -webkit-center;
    }
    div.dataTables_wrapper div.dataTables_filter {
        text-align: end;
    }

</style>

<div id="paineis">

    <ol class="breadcrumb page-breadcrumb">
        <?=parametro::getBreadCrumbMenu($nomeModulo)?>
        <li class="position-absolute pos-top pos-right d-none d-sm-block"><span class="js-get-date"></span></li>
    </ol>

    <div class="row">
        <div class="col-xl-12">
            <div id="panel-1" class="panel"
                data-panel-color="false" 
                data-panel-collapsed="false" 
                data-panel-close="false" 
                data-panel-refresh="false" 
                data-panel-lock="false" 
                data-panel-locked="false" 
                data-panel-refresh="false" 
                data-panel-sortable="false"
                data-panel-reset="false"
            >
                <div class="panel-hdr">
                    <h2>
                        Lista <span class="fw-300" data-i18n=""><i><?=$nomeMenu?></i></span>
                    </h2>
                </div>
                <div class="panel-container show">
                    <div class="panel-content table-responsive">
                        <!-- datatable start -->
                        <table id="TabelaEditor" class="table table-bordered table-hover table-striped w-100" cellspacing="0" width="100%">
                            <thead>
                                <tr>
                                    @tablefields
                                </tr>
                            </thead>
                        </table>
                        <!-- datatable end -->

                        <hr>
                        <div id="segundoDataTable"></div>

                    </div>
                </div>
            </div>
        </div>
    </div>

    <div id="loader-wrapper" style="display: none;">
        <div id="loader"></div>
    </div>

</div>

<script>
    if(typeof jQuery == 'undefined'){
        document.write('<link id="vendorsbundle" rel="stylesheet" media="screen, print" href="<?=$full_url?>/<?=PASTA_PRINCIPAL?>/css/vendors.bundle.css"></'+'link>');
        document.write('<link id="vendorsbundle" rel="stylesheet" media="screen, print" href="<?=$full_url?>/<?=PASTA_PRINCIPAL?>/css/app.bundle.css"></'+'link>');   
        document.write('<script type="text/javascript" src="<?=$full_url?>/<?=PASTA_PRINCIPAL?>/js/vendors.bundle.js"></'+'script>');
        document.write('<script type="text/javascript" src="<?=$full_url?>/<?=PASTA_PRINCIPAL?>/js/app.bundle.js"></'+'script>');
    }
</script>

<script src="<?=$full_url?>/<?=PASTA_PRINCIPAL?>/assets/moment/moment.js"></script>

<!-- datepicker -->
<script src="<?=$full_url?>/<?=PASTA_PRINCIPAL?>/assets/datepicker/bootstrap-datepicker.js" type="text/javascript"></script>
<script src="<?=$full_url?>/<?=PASTA_PRINCIPAL?>/assets/daterangepicker/daterangepicker.js" type="text/javascript"></script>
<script src="<?=$full_url?>/<?=PASTA_PRINCIPAL?>/assets/datepicker/bootstrap-datepicker.pt-BR.js" type="text/javascript"></script>

<!-- DATA TABES SCRIPT -->
<script type="text/javascript" language="javascript" src="<?=$full_url?>/<?=PASTA_PRINCIPAL?>/assets/papaparse/papaparse.min.js"></script>
<script type="text/javascript" language="javascript" src="<?=$full_url?>/<?=PASTA_PRINCIPAL?>/js/datagrid/datatables/datatables.bundle.js"></script>

<script type="text/javascript" language="javascript" src="<?=$full_url?>/<?=PASTA_PRINCIPAL?>/assets/datatables1_9_6/Editor-1.9.6/js/dataTables.editor.js"></script>
<script type="text/javascript" language="javascript" src="<?=$full_url?>/<?=PASTA_PRINCIPAL?>/assets/datatables1_9_6/Select-1.3.1/js/dataTables.select.js"></script>
<script type="text/javascript" language="javascript" src="<?=$full_url?>/<?=PASTA_PRINCIPAL?>/assets/datatables1_9_6/Buttons-1.6.5/js/dataTables.buttons.js"></script>
<script type="text/javascript" language="javascript" src="<?=$full_url?>/<?=PASTA_PRINCIPAL?>/assets/datatables1_9_6/JSZip-2.5.0/jszip.js"></script>
<script type="text/javascript" language="javascript" src="<?=$full_url?>/<?=PASTA_PRINCIPAL?>/assets/datatables1_9_6/pdfmake-0.1.36/pdfmake.js"></script>
<script type="text/javascript" language="javascript" src="<?=$full_url?>/<?=PASTA_PRINCIPAL?>/assets/datatables1_9_6/pdfmake-0.1.36/vfs_fonts.js"></script>
<script type="text/javascript" language="javascript" src="<?=$full_url?>/<?=PASTA_PRINCIPAL?>/assets/datatables1_9_6/Buttons-1.6.5/js/buttons.html5.js"></script>
<script type="text/javascript" language="javascript" src="<?=$full_url?>/<?=PASTA_PRINCIPAL?>/assets/datatables1_9_6/Buttons-1.6.5/js/buttons.print.js"></script>
<script type="text/javascript" language="javascript" src="<?=$full_url?>/<?=PASTA_PRINCIPAL?>/assets/datatables1_9_6/select2-4.0.2/select2.min.js"></script>
<script type="text/javascript" language="javascript" src="<?=$full_url?>/<?=PASTA_PRINCIPAL?>/assets/datatables1_9_6/select2-4.0.2/editor.select2.js"></script>

<script>

    var editor;
    var table;
    var conferencia;
    var inicio;

    $(document).ready(function()
    {

        $('#paineis').smartPanel({
            customButton: true,
            customButtonLabel: "Criar Atalho",
            onCustom: function () {

            },
        });
        load_lang();

        $(".js-panel-custombutton").on("click", function() {
            var arrAtalhos = JSON.parse(localStorage.getItem("shortcuts"));
            if(!arrAtalhos) arrAtalhos = [];

            arrAtalhos.push({
                "nome": "Cadastro " + ("<?=$nomeMenu?>"),
                "modulo": "<?=$nomeModulo?>",
                "icone": "<?=$nomeIcone?>"
            })

            arrAtalhos = arrAtalhos.filter(function (a) {
                return !this[JSON.stringify(a)] && (this[JSON.stringify(a)] = true);
            }, Object.create(null))

            localStorage.setItem('shortcuts', JSON.stringify(arrAtalhos));

            $("#modal-shortcut").modal("show");
            
            setTimeout(() => {
                createListaAtalhos();
            }, 1000);

        })

        inicio = performance.now();
                    
        editor = new $.fn.dataTable.Editor( {
            ajax: "modules/<?=$nomeModulo?>/data.php",
            table: "#TabelaEditor",
            fields: [ 
                @editorfields
            ],
            <?php include PASTA_COMPLETA.'/modules/langDatatables/editor.php'; ?>
        } );

        editor.on( 'preOpen', function ( e, type ) {

            var mode = editor.mode()
            setTimeout(() => {
                $(".DTE_Header").addClass("bg-primary text-white");
                $(".DTE_Form_Buttons .btn").addClass("btn-primary");
            }, 300);
        } );


        // Upload Editor - triggered from the import button. Used only for uploading a file to the browser
        var uploadEditor = new $.fn.dataTable.Editor( {
            fields: [ {
                label: 'Arquivo CSV:',
                name: 'csv',
                type: 'upload',
                ajax: function ( files ) {
                    // Ajax override of the upload so we can handle the file locally. Here we use Papa
                    // to parse the CSV.
                    Papa.parse(files[0], {
                        header: true,
                        skipEmptyLines: true,
                        complete: function (results) {
                            if ( results.errors.length ) {
                                console.log( results );
                                uploadEditor.field('csv').error( 'CSV parsing error: '+ results.errors[0].message );
                            }
                            else {
                                uploadEditor.close();
                                selectColumns( editor, results.data, results.meta.fields );
                            }
                        }
                    });
                }
            } ]
        } );

        table = $('#TabelaEditor').DataTable( {
            dom: "<'row'<'col-sm-2'l><'col-sm-7 d-flex justify-content-center'B><'col-sm-3 d-flex justify-content-end'f>>" +
                    "<'row'<'col-sm-12'tr>>" +
                    "<'row'<'col-sm-5'i><'col-sm-7'p>>",
            // dom: 'lBfrtip',
            select: true,
            //serverSide: true,
            processing : true,
            responsive: false,
            lengthChange: true,
            colReorder: true,
            lengthMenu: [[5, 10, 25, 50, -1], [5, 10, 25, 50, "All"]],
            stateSave: true,
            stateSaveCallback: function ( settings, data ) {
                localStorage.setItem( 'datatables_<?=$nomeModulo?>', JSON.stringify( data ) );
            },
            stateLoadCallback: function ( ) {
                try {
                    return JSON.parse( localStorage.getItem( 'datatables_<?=$nomeModulo?>' ) );
                } catch (e) {}
            },
            ajax: {
                url: "modules/<?=$nomeModulo?>/data.php",
                type: "POST",
                beforeSend: function(){
                    inicio = performance.now();
                }
            },
            "initComplete": function(settings, json) {
                var segundosF = performance.now() - inicio
                
                var x = segundosF / 1000
                var seconds = x % 60
                
                $("#segundoDataTable").html("Tempo de recuperação: "+seconds.toFixed(2)+" segundos")
                
            },
            "drawCallback": function( settings ) {
                var segundosF = performance.now() - inicio
                
                var x = segundosF / 1000
                var seconds = x % 60
                
                $("#segundoDataTable").html("Tempo de recuperação: "+seconds.toFixed(2)+" segundos")
            },
            <?php include PASTA_COMPLETA.'/modules/langDatatables/table.php'; ?>
            columns: [
                @datafields
            ],
            // order: [[ 2, 'asc' ], [ 4, 'asc' ]],
            buttons: [
                <?php if( parametro::getAcesso($nomeModulo, $_COOKIE['s3P'], 1)):?>
                    { 
                        extend: "create",
                        editor: editor,
                        className: 'btn-success btn-sm mr-1',
                        text: '<i class="fal fa-plus mr-1"></i> Add'
                    },
                <?php endif; ?>
                <?php if( parametro::getAcesso($nomeModulo, $_COOKIE['s3P'], 2)):?>
                    { 
                        extend: "edit",  
                        editor: editor,
                        className: 'btn-info btn-sm mr-1',
                        text: '<i class="fal fa-edit mr-1"></i> Editar'
                    },
                <?php endif; ?>
                <?php if( parametro::getAcesso($nomeModulo, $_COOKIE['s3P'], 3)):?>
                    // { 
                    //     extend: "remove", 
                    //     editor: editor, 
                    //     className: 'btn-danger btn-sm mr-1',
                    //     text: '<i class="fal fa-times mr-1"></i> Remover'
                    // },
                <?php endif; ?>
                <?php if( parametro::getAcesso($nomeModulo, $_COOKIE['s3P'], 4)):?>
                    {
                        extend: 'collection',
                        text: 'Exportar',
                        className: 'btn-primary btn-sm mr-1',
                        buttons: [
                            'csv',
                            'excel',
                            'pdf',
                            'print',
                            'copy'
                        ]
                    },
                <?php endif; ?>
                <?php if( parametro::getAcesso($nomeModulo, $_COOKIE['s3P'], 5)):?>
                    {
                        text: 'Importar CSV',
                        className: 'btn-primary btn-sm mr-1',
                        action: function () {
                            uploadEditor.create( {
                                title: 'Importar arquivo CSV'
                            } );
                        }
                    },
                <?php endif; ?>
                {
                    extend: 'colvis',
                    text: 'Visualizar Colunas',
                    className: 'btn-primary btn-sm mr-1'
                },
                {
                    text: '<i class="fal fa-sync mr-1"></i> Sincronizar',
                    name: 'refresh',
                    className: 'btn-primary btn-sm',
                    action: function(e, dt, node, config) {
                        //alert('por enquanto não faço nada!');
                        table.ajax.reload();
                    }
                }
            ]
        } );

    });

    // Exibe um formulário do Editor que permite ao usuário escolher os dados CSV para aplicar a cada coluna
    function selectColumns ( editor, csv, header ) {
        var selectEditor = new $.fn.dataTable.Editor();
        var fields = editor.order();
    
        for ( var i=0 ; i<fields.length ; i++ ) {
            var field = editor.field( fields[i] );
    
            selectEditor.add( {
                label: field.label(),
                name: field.name(),
                type: 'select',
                options: header,
                def: header[i]
            } );
        }
    
        selectEditor.create({
            title: 'Mapa campos CSV',
            buttons: 'Importar '+csv.length+' registros',
            message: 'Selecione a coluna CSV da qual deseja usar os dados para cada campo.'
        });
    
        selectEditor.on('submitComplete', function (e, json, data, action) {
            // Use a instância do Editor do host para mostrar um formulário de criação de várias linhas que permite ao usuário enviar os dados.
            editor.create( csv.length, {
                title: 'Confirmar importação',
                buttons: 'Submit',
                message: 'Click em <i>Submit</i> para confirmar a importação de '+csv.length+' linhas. Opcionalmente, substitua o valor de um campo para definir um valor comum clicando no campo abaixo.'
            } );
    
            for ( var i=0 ; i<fields.length ; i++ ) {
                var field = editor.field( fields[i] );
                var mapped = data[ field.name() ];
    
                for ( var j=0 ; j<csv.length ; j++ ) {
                    field.multiSet( j, csv[j][mapped] );
                }
            }
        } );
    }

</script>
