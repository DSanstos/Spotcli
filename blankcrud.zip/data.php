<?php

//INICIO A SESSÃO
session_start();

// DataTables PHP library and database connection
include( "../../lib/DataTables.php" );

// Alias Editor classes so they are easy to use
use
	DataTables\Editor,
	DataTables\Editor\Field,
	DataTables\Editor\Format,
	DataTables\Editor\Mjoin,
	DataTables\Editor\Options,
	DataTables\Editor\Upload,
	DataTables\Editor\Validate,
	DataTables\Editor\ValidateOptions;

// Build our Editor instance and process the data coming from _POST
Editor::inst( $db, @table, @key )
	->fields(
		@fields
	)
		@join
	->process( $_POST )
	->json();
